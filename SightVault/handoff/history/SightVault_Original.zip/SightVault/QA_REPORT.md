# SightVault QA

- 24 functional tests passed. Coverage includes safe re-indexing, changed files, duplicate timestamps, corrupt images, missing models, exact code ranking, semantic mode separation, whole-corpus chronological retrieval, date boundaries, image serving and local-origin restrictions.
- All seven retrieval benchmark cases passed against the real 62-image index, including direct visual retrieval of the red backpack. See `QA_RESULTS.json`.
- MiniCPM-OCR 1.0 and MiniCPM-V 4.7 1B were run on the actual CUDA screenshot. OCR recovered the CUDA error. Analysis identified the memory failure and distinguished a likely cause from an observed fact.
- The demo index uses RapidOCR. Both OCR backends were tested; the app records the backend per image.
- The interface was inspected in the in-app browser. Source images and thumbnails rendered. Live checks exposed a Windows PyTorch cache initialization problem; the app now assigns writable local temporary and compiler-cache paths before model imports.
- Outbound-blocked verification passed: real semantic search, MiniCPM-OCR and MiniCPM-V analysis completed. Peak GPU allocation was 3.99 GiB. See `OFFLINE_VERIFICATION.json`. Loopback connections remain allowed for local runtime IPC.
- The live browser demo query “Find the screenshot where my GPU ran out of memory” retrieved `terminal_cuda_01.png` first, with a 0.694 cosine similarity and an OCR match.

Hardware: NVIDIA RTX 4070, 12 GB VRAM. First-use model loading is substantially slower than warm retrieval. Windows reference MiniCPM kernels are used.

Scope: this is a local hackathon MVP. Natural-language date parsing is limited to first/earliest/oldest intent plus explicit date filters. PDFs require export to images. Generated demo timestamps are fictional.
