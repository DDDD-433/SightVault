"""Start a hidden localhost service and open the app in the default browser."""
from pathlib import Path
import json,os,subprocess,sys,time,urllib.request,webbrowser

ROOT=Path(__file__).resolve().parent.parent
URL='http://127.0.0.1:7860'

def running():
    try:
        with urllib.request.urlopen(URL+'/api/status',timeout=1) as r:
            return json.load(r).get('embedding_model','').startswith('EmbeddingGemma')
    except Exception:return False

if not running():
    (ROOT/'data').mkdir(exist_ok=True)
    log=open(ROOT/'data'/'server.log','a',encoding='utf8')
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    subprocess.Popen([sys.executable,'-u',str(ROOT/'app.py')],cwd=ROOT,stdout=log,stderr=log,creationflags=flags)
    for _ in range(40):
        if running():break
        time.sleep(.25)
    else:
        print('Could not start SightVault. Check data/server.log.');sys.exit(1)
webbrowser.open(URL)
print('SightVault is running at '+URL)
