import argparse,json,sys,time,socket
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from sightvault.config import Config
from sightvault.database import Database
from sightvault.models import Models
from sightvault.search import Search

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--offline-check',action='store_true');parser.add_argument('--output',default='QA_RESULTS.json');args=parser.parse_args()
    if args.offline_check:
        original_connect=socket.socket.connect
        def reject_network(self,address):
            if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1','localhost'):
                return original_connect(self,address)
            raise RuntimeError('Outbound network blocked by offline verification')
        socket.socket.connect=reject_network
    config=Config();search=Search(Database(config.db_path),Models(config))
    cases=[
      ('Find the screenshot where my GPU ran out of memory','hybrid','relevance','terminal_cuda'),
      ('GPU memory problem','semantic','relevance','terminal_cuda'),
      ('Find ERESOLVE','hybrid','relevance','terminal_eresolve'),
      ('ModuleNotFoundError','exact','relevance','terminal_module'),
      ('Show slides about databases','semantic','relevance',('lecture_normalization','lecture_erd','lecture_joins')),
      ('Find the image with a red backpack','semantic','relevance','object_study_01'),
      ('When did the CUDA error first occur?','hybrid','oldest','terminal_cuda_01'),
      ('Find the receipt where I bought a keyboard','hybrid','relevance',('receipt_022','receipt_028')),
    ]
    rows=[]
    for query,mode,sort,expected in cases:
        r=search.run(query,mode=mode,sort=sort)
        names=[a['filename'] for a in r['results']]
        good=bool(names) and names[0].startswith(expected)
        row={'query':query,'mode':mode,'top1_correct':good,'expected_prefix':expected,'results':names,'latency_ms':r['latency_ms'],'warning':r['warning']}
        rows.append(row);print(json.dumps(row),flush=True)
    report={'offline_network_blocked':args.offline_check,'cases':rows,'passed':sum(r['top1_correct'] for r in rows),'total':len(rows),'database':Database(config.db_path).stats()}
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf8')
    return int(report['passed']!=report['total'])

if __name__=='__main__':sys.exit(main())
