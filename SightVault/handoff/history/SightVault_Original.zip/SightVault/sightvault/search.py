import re
import time
from datetime import date, timedelta
import numpy as np
from .database import decode_vector
from .models import EMBEDDING_ID

STOPWORDS = set('a an the i my me you your our it this that these those is was were be been being of for to from in on at with where when did does do find show search screenshot screenshots picture pictures image images photo photos please containing contains about what how earliest first occur appeared happen happened out'.split())

def query_terms(query):
    return [t for t in re.findall(r'[\w]+', query.casefold()) if t not in STOPWORDS and len(t)>1][:32]

def public_asset(row):
    return {k:v for k,v in row.items() if k not in ('embedding','image_path','thumbnail_path')}

def date_bounds(start, end):
    try:
        low = date.fromisoformat(start).isoformat()+'T00:00:00+00:00' if start else None
        high = (date.fromisoformat(end)+timedelta(days=1)).isoformat()+'T00:00:00+00:00' if end else None
    except ValueError as exc:
        raise ValueError('Dates must use YYYY-MM-DD.') from exc
    if low and high and low >= high:
        raise ValueError('The end date must be on or after the start date.')
    return low, high

class Search:
    def __init__(self, db, models):
        self.db, self.models = db, models

    def run(self, query='', mode='hybrid', sort='relevance', top_k=5, start=None,end=None,folder=None,similar_id=None):
        began = time.perf_counter()
        query = query.strip()
        if sort == 'relevance' and re.search(r'\b(first|earliest|oldest)\b', query, re.I):
            sort = 'oldest'
        low, high = date_bounds(start,end)
        rows = self.db.all(low,high,folder)
        terms = query_terms(query)
        warning, qvec = None, None
        source = None
        if similar_id is not None:
            source = self.db.get(similar_id)
            if not source or not source['embedding']:
                raise ValueError('This image has no semantic embedding. Re-index after installing the model.')
            qvec = decode_vector(source['embedding'])
        elif query and mode != 'exact' and any(row['embedding'] for row in rows):
            try: qvec = self.models.embed_query(query)
            except Exception as exc: warning = 'Semantic model unavailable; showing text matches only. ' + str(exc)
        elif query and mode != 'exact' and rows:
            warning = 'No semantic vectors are indexed. Showing text matches only.'
        fts = self.db.fts(terms) if query and mode != 'semantic' and similar_id is None else {}
        max_fts = max(fts.values(), default=1) or 1
        ranked=[]
        for row in rows:
            if source and row['id'] == source['id']: continue
            ocr = row['ocr_text'].casefold()
            filename = row['filename'].casefold().replace('_',' ')
            text = ocr + ' ' + filename
            matched = [t for t in terms if t in text]
            ocr_matched = [t for t in terms if t in ocr]
            coverage = len(matched) / max(len(terms),1)
            exact = bool(terms) and all(t in ocr for t in terms)
            phrase = query.casefold().strip('"\'')
            phrase_match = bool(phrase) and phrase in ocr
            # Error identifiers and quoted phrases get a strong literal-match boost.
            literals = re.findall(r'"([^"]+)"',query) or [w for w in re.findall(r'\b[A-Za-z][A-Za-z0-9_]+\b',query) if any(c.isupper() for c in w[1:]) or any(c.isdigit() for c in w)]
            literal_match = bool(literals) and all(w.casefold() in ocr for w in literals)
            lexical = 0.8*coverage + 0.2*(fts.get(row['id'],0)/max_fts)
            semantic = None
            if qvec is not None and row['embedding'] and row['embedding_model'] == EMBEDDING_ID:
                vector = decode_vector(row['embedding'])
                if vector.shape == qvec.shape:
                    semantic = float(np.clip(np.dot(qvec,vector), -1, 1))
            if not query and source is None:
                score = 0.0
            elif mode == 'exact':
                if not matched: continue
                score = lexical + 0.7*exact + 0.4*phrase_match + 0.6*literal_match
            elif mode == 'semantic' or source is not None:
                if semantic is None: continue
                score = semantic
            else:
                if semantic is None and not matched: continue
                score = 0.7*max(semantic or 0,0) + 0.3*lexical + 0.65*literal_match + 0.35*exact + 0.25*phrase_match
            result = public_asset(row)
            result.update(score=round(score,4), semantic_score=round(semantic,4) if semantic is not None else None,
                lexical_score=round(lexical,4),exact_match=exact or phrase_match or literal_match,
                matched_terms=ocr_matched,ocr_preview=row['ocr_text'][:250])
            ranked.append(result)
        ranked.sort(key=lambda r:(-r['score'],r['timestamp'],r['id']))
        temporal = sort in ('oldest','newest')
        if temporal and query and ranked:
            # Filter before chronological sorting across the entire corpus, never just top K.
            exact_rows = [r for r in ranked if r['exact_match']]
            if exact_rows and mode != 'semantic':
                ranked = exact_rows
            elif mode == 'exact' or qvec is None:
                best = max(r['lexical_score'] for r in ranked)
                ranked = [r for r in ranked if r['lexical_score'] >= best * 0.8]
            else:
                best = max(r['semantic_score'] or -1 for r in ranked)
                ranked = [r for r in ranked if r['semantic_score'] is not None and r['semantic_score'] >= best-0.035]
        total = len(ranked)
        if temporal: ranked.sort(key=lambda r:(r['timestamp'],r['id']),reverse=sort=='newest')
        return {'results':ranked[:top_k], 'total_matches':total, 'query':query, 'mode':mode,'sort':sort,
                'latency_ms':round((time.perf_counter()-began)*1000,1), 'warning':warning,
                'temporal_note':'Earliest matching file in your index. File timestamps are evidence of the file date, not proof of when an event happened.' if temporal and query else None}
